// إعدادات مشروع Firebase الخاص بـ TARRAB
export const firebaseConfig = {
  apiKey: 'AIzaSyBikyiFfcCPgkf7aTgpx03e2SK_PMl-H9I',
  authDomain: 'tarrab-2c971.firebaseapp.com',
  projectId: 'tarrab-2c971',
  storageBucket: 'tarrab-2c971.firebasestorage.app',
  messagingSenderId: '1096593184847',
  appId: '1:1096593184847:web:974303689af3476129723a',
};
