import { PAGES, CURRENCIES, EXPENSE_PAGES, pageById, sectionsOf } from './pages.js';
import { store, isConfigured } from './store.js';

const $ = (sel, root = document) => root.querySelector(sel);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const state = {
  entries: [],
  sync: 'loading',
  page: 'main',
  collapsed: loadJSON('hesabat.collapsed', {}),
  lastSection: loadJSON('hesabat.lastSection', {}),
};

function loadJSON(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch (_) { return d; } }
function saveJSON(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) { /* ignore */ } }
function deviceName() {
  try {
    const n = localStorage.getItem('hesabat.device');
    if (n) return n;
  } catch (_) { /* ignore */ }
  return /iPhone|iPad/i.test(navigator.userAgent) ? 'آيفون' : /Android/i.test(navigator.userAgent) ? 'أندرويد' : 'جهاز';
}

/* ---------------- أرقام وتواريخ ---------------- */
const nf = new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 });
const fmt = (n) => nf.format(Math.round(n * 100) / 100);
const money = (n, cur) => (cur === '$' ? `$${fmt(n)}` : `${fmt(n)} ${cur}`).replace('$-', '-$');
function fmtDate(d) {
  if (!d) return '—';
  const [y, m, day] = d.split('-');
  return `${day}/${m}/${y}`;
}
function today() {
  const t = new Date();
  return `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`;
}
function parseNum(s) {
  if (typeof s === 'number') return s;
  const v = String(s || '').replace(/[٠-٩]/g, (c) => '٠١٢٣٤٥٦٧٨٩'.indexOf(c)).replace(/٫/g, '.').replace(/[,،\s]/g, '');
  return v === '' ? NaN : Number(v);
}

/* ---------------- الحسابات ---------------- */
function entriesOf(pageId, sectionIds) {
  return state.entries.filter((e) => e.page === pageId && (!sectionIds || sectionIds.includes(e.section)));
}
// المجموع بالدولار + مجاميع العملات الأخرى
function totals(list) {
  const t = { usd: 0, other: {}, count: 0 };
  list.forEach((e) => {
    if (e.excluded) return;
    t.count++;
    if (e.currency === '$') t.usd += e.amount;
    else {
      t.other[e.currency] = (t.other[e.currency] || 0) + e.amount;
      if (e.usd !== null && e.usd !== undefined) t.usd += e.usd;
    }
  });
  return t;
}
const pageUSD = (id) => totals(entriesOf(id)).usd;

function sortEntries(list) {
  return list.slice().sort((a, b) => (b.date || '').localeCompare(a.date || '') || (b.order || 0) - (a.order || 0));
}

/* ---------------- الواجهة ---------------- */
const ICONS = {
  main: '<path d="M3 11l9-7 9 7"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
  transfers: '<path d="M4 8h13l-3-3"/><path d="M20 16H7l3 3"/>',
  site: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3a14 14 0 0 1 0 18a14 14 0 0 1 0-18"/>',
  ghufran: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  debts: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/>',
  apps: '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
  sahban: '<path d="M3 7h18v10H3z"/><circle cx="12" cy="12" r="2.5"/>',
  syrian: '<ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v6c0 1.7 3.1 3 7 3s7-1.3 7-3V6"/><path d="M5 12v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6"/>',
  family: '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>',
};
const icon = (id) => `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${ICONS[id] || ''}</svg>`;

function renderNav() {
  const nav = $('#nav');
  nav.innerHTML = PAGES.map((p) => {
    const t = p.dashboard ? null : totals(entriesOf(p.id, p.summary && p.summary[0].sections));
    const val = p.dashboard
      ? money(pageUSD('main') - EXPENSE_PAGES.reduce((s, id) => s + pageUSD(id), 0), '$')
      : p.summary && p.summary[0].only && p.summary[0].only !== '$'
        ? money(t.other[p.summary[0].only] || 0, p.summary[0].only)
        : money(t.usd, '$');
    return `
      ${p.separate ? '<div class="nav-sep"><span>صفحة مستقلة</span></div>' : ''}
      <button class="nav-item ${p.id === state.page ? 'active' : ''} ${p.separate ? 'nav-family' : ''}" data-page="${p.id}" ${p.id === state.page ? 'aria-current="page"' : ''}>
        <span class="nav-ico" aria-hidden="true">${icon(p.id)}</span>
        <span class="nav-title">${esc(p.title)}</span>
        <span class="nav-val">${val}</span>
      </button>`;
  }).join('');
}

let drawerOpen = false;
function openDrawer() {
  renderNav();
  drawerOpen = true;
  $('#drawer').classList.add('open');
  $('#menu-btn').setAttribute('aria-expanded', 'true');
  history.pushState({ drawer: 1 }, '');
}
function closeDrawer(fromPop) {
  if (!drawerOpen) return;
  drawerOpen = false;
  $('#drawer').classList.remove('open');
  $('#menu-btn').setAttribute('aria-expanded', 'false');
  if (!fromPop) history.back();
}

function totalsLine(t, only) {
  const parts = [];
  if (!only || only === '$') parts.push(`<span class="amt ${t.usd < 0 ? 'neg' : ''}">${money(t.usd, '$')}</span>`);
  Object.entries(t.other).forEach(([c, v]) => {
    if (!only || only === c) parts.push(`<span class="amt sub ${v < 0 ? 'neg' : ''}">${money(v, c)}</span>`);
  });
  return parts.join('');
}

function renderDashboard() {
  const received = pageUSD('main');
  const rows = EXPENSE_PAGES.map((id) => ({ id, title: pageById(id).title, v: pageUSD(id) }));
  const spent = rows.reduce((s, r) => s + r.v, 0);
  const rest = received - spent;
  return `
    <section class="hero">
      <div class="hero-label">الباقي</div>
      <div class="hero-value ${rest < 0 ? 'neg' : ''}">${money(rest, '$')}</div>
      <div class="hero-split">
        <div><span>مجموع المستلم</span><b>${money(received, '$')}</b></div>
        <div><span>مجموع المصروف</span><b>${money(spent, '$')}</b></div>
      </div>
    </section>
    <section class="card breakdown">
      <h3 class="card-title">تفاصيل المصروف</h3>
      ${rows.map((r) => `
        <button class="brow" data-page="${r.id}">
          <span>${esc(r.title)}</span>
          <span class="brow-bar"><i style="width:${spent ? Math.max(2, (r.v / spent) * 100) : 0}%"></i></span>
          <b>${money(r.v, '$')}</b>
        </button>`).join('')}
    </section>
  `;
}

function renderSummary(page) {
  if (!page.summary) return '';
  return `<section class="summary">${page.summary.map((s) => {
    const t = totals(entriesOf(page.id, s.sections));
    return `<div class="sum-item"><span>${esc(s.label)}</span><div class="sum-val">${totalsLine(t, s.only)}</div></div>`;
  }).join('')}</section>`;
}

function renderEntry(e) {
  const hasUsd = e.currency !== '$' && e.usd !== null && e.usd !== undefined;
  return `
    <li class="entry ${e.excluded ? 'excluded' : ''}" data-id="${e.id}" tabindex="0">
      <div class="e-main">
        <div class="e-details">${e.details ? esc(e.details) : `<span class="e-date-main">${fmtDate(e.date)}</span>`}</div>
        <div class="e-meta">${[e.details ? fmtDate(e.date) : '', e.by ? esc(e.by) : '', e.excluded ? '<span class="badge">لا يُحسب</span>' : ''].filter(Boolean).join(' · ')}</div>
      </div>
      <div class="e-amt">
        <div class="amt ${e.amount < 0 ? 'neg' : ''}">${money(e.amount, e.currency)}</div>
        ${hasUsd ? `<div class="e-usd">≈ ${money(e.usd, '$')}</div>` : ''}
      </div>
    </li>`;
}

function renderSection(page, sec, multi) {
  const list = sortEntries(entriesOf(page.id, [sec.id]));
  const t = totals(list);
  const key = `${page.id}.${sec.id}`;
  const collapsed = !!state.collapsed[key];
  return `
    <section class="card section ${collapsed ? 'collapsed' : ''}">
      <header class="sec-head" ${multi ? `data-collapse="${key}" role="button" tabindex="0" aria-expanded="${!collapsed}"` : ''}>
        <div>
          <h3 class="card-title">${esc(sec.title)}</h3>
          <div class="sec-count">${list.length} قيد</div>
        </div>
        <div class="sec-total" ${multi ? '' : 'hidden'}>
          <span class="sec-total-label">${esc(sec.totalLabel || 'المجموع')}</span>
          <div>${totalsLine(t)}</div>
        </div>
        ${multi ? '<span class="chev" aria-hidden="true"></span>' : ''}
      </header>
      <div class="sec-body">
        ${list.length ? `<ul class="entries">${list.map(renderEntry).join('')}</ul>` : '<p class="empty">لا توجد قيود بعد — اضغط زر الإضافة</p>'}
        <button class="add-inline" data-add="${sec.id}">+ إضافة إلى ${esc(sec.title)}</button>
      </div>
    </section>`;
}

function renderPage() {
  const page = pageById(state.page) || PAGES[0];
  const multi = sectionsOf(page).length > 1;
  let html = `<div class="page-head"><h2 class="page-title">${esc(page.title)}</h2>${page.separate ? '<span class="pill">صفحة مستقلة</span>' : ''}</div>`;
  if (page.dashboard) html += renderDashboard();
  html += renderSummary(page);
  page.groups.forEach((g) => {
    if (g.title) html += `<h3 class="group-title">${esc(g.title)}</h3>`;
    html += g.sections.map((s) => renderSection(page, s, multi)).join('');
  });
  $('#content').innerHTML = html;
}

function renderStatus() {
  const map = {
    loading: ['جارٍ التحميل…', 'wait'], synced: ['متزامن', 'ok'], pending: ['بانتظار الرفع', 'wait'],
    cache: ['غير متصل — يعمل بدون إنترنت', 'off'], connecting: ['جارٍ الاتصال…', 'wait'], local: ['وضع المعاينة', 'off'], error: ['خطأ في الاتصال', 'err'],
  };
  const [label, cls] = map[state.sync] || map.loading;
  $('#sync').className = `sync ${cls}`;
  $('#sync-label').textContent = label;
}

function render() { renderNav(); renderPage(); renderStatus(); }

/* ---------------- نافذة الإضافة / التعديل ---------------- */
let sheetOpen = false;
function openSheet(html, onMount) {
  $('#sheet-body').innerHTML = html;
  $('#sheet').hidden = false;
  requestAnimationFrame(() => $('#sheet').classList.add('open'));
  if (!sheetOpen) { history.pushState({ sheet: 1 }, ''); sheetOpen = true; }
  onMount && onMount($('#sheet-body'));
}
function closeSheet(fromPop) {
  if (!sheetOpen) return;
  sheetOpen = false;
  $('#sheet').classList.remove('open');
  setTimeout(() => { if (!sheetOpen) $('#sheet').hidden = true; }, 220);
  if (!fromPop) history.back();
}
window.addEventListener('popstate', () => { if (sheetOpen) closeSheet(true); else if (drawerOpen) closeDrawer(true); });

function entryForm(entry, presetSection) {
  const page = pageById(entry ? entry.page : state.page);
  const secs = sectionsOf(page);
  const sectionId = entry ? entry.section : presetSection || state.lastSection[page.id] || secs[0].id;
  const cur = entry ? entry.currency : '$';
  const neg = entry ? entry.amount < 0 : false;
  const amount = entry ? Math.abs(entry.amount) : '';
  const groupLabel = (s) => {
    const g = page.groups.find((gr) => gr.sections.includes(s));
    return g && g.title && page.groups.length > 1 ? `${g.title} — ` : '';
  };
  return `
    <form id="entry-form" autocomplete="off" novalidate>
      <div class="sheet-head">
        <h3>${entry ? 'تعديل القيد' : 'إضافة جديدة'}</h3>
        <span class="muted">${esc(page.title)}</span>
      </div>
      ${secs.length > 1 ? `
        <label class="field">
          <span>القسم</span>
          <select name="section">${secs.map((s) => `<option value="${s.id}" ${s.id === sectionId ? 'selected' : ''}>${esc(groupLabel(s) + s.title)}</option>`).join('')}</select>
        </label>` : `<input type="hidden" name="section" value="${secs[0].id}">`}
      <div class="field">
        <span>المبلغ</span>
        <div class="amount-row">
          <button type="button" class="sign ${neg ? 'neg' : ''}" data-sign aria-label="تبديل الإشارة">${neg ? '−' : '+'}</button>
          <input name="amount" inputmode="decimal" placeholder="0" value="${amount}" required>
        </div>
        <small class="hint">${neg ? 'سالب: دفعة / خصم' : 'اضغط + لتحويله إلى سالب (دفعة أو خصم)'}</small>
      </div>
      <div class="field">
        <span>نوع العملة</span>
        <div class="seg" role="radiogroup">
          ${CURRENCIES.map((c) => `<label><input type="radio" name="currency" value="${c}" ${c === cur ? 'checked' : ''}><span>${c}</span></label>`).join('')}
        </div>
      </div>
      <label class="field usd-field" ${cur === '$' ? 'hidden' : ''}>
        <span>ما يعادل بالدولار <small class="muted">(اختياري — يدخل في المجموع بالدولار)</small></span>
        <input name="usd" inputmode="decimal" placeholder="مثال: 1404" value="${entry && entry.usd !== null && entry.usd !== undefined && entry.currency !== '$' ? entry.usd : ''}">
      </label>
      <label class="field">
        <span>التاريخ</span>
        <input type="date" name="date" value="${entry ? entry.date || '' : today()}">
      </label>
      <label class="field">
        <span>التفاصيل</span>
        <input name="details" placeholder="مثال: حوالة" value="${esc(entry ? entry.details : '')}">
      </label>
      <label class="check">
        <input type="checkbox" name="excluded" ${entry && entry.excluded ? 'checked' : ''}>
        <span>لا يُحسب في المجموع</span>
      </label>
      <p class="form-error" hidden></p>
      <div class="sheet-actions">
        <button type="submit" class="btn primary">${entry ? 'حفظ التعديل' : 'إضافة'}</button>
        ${entry ? '<button type="button" class="btn danger" data-delete>حذف</button>' : ''}
        <button type="button" class="btn ghost" data-close>إلغاء</button>
      </div>
    </form>`;
}

function openEntry(entry, presetSection) {
  openSheet(entryForm(entry, presetSection), (root) => {
    const form = $('#entry-form', root);
    const sign = $('[data-sign]', form);
    sign.addEventListener('click', () => {
      sign.classList.toggle('neg');
      const neg = sign.classList.contains('neg');
      sign.textContent = neg ? '−' : '+';
      $('.hint', form).textContent = neg ? 'سالب: دفعة / خصم' : 'اضغط + لتحويله إلى سالب (دفعة أو خصم)';
    });
    form.addEventListener('change', (ev) => {
      if (ev.target.name === 'currency') $('.usd-field', form).hidden = ev.target.value === '$';
    });
    if (!entry) setTimeout(() => form.amount.focus(), 250);
    const del = $('[data-delete]', form);
    if (del) del.addEventListener('click', () => confirmDelete(entry));
    form.addEventListener('submit', (ev) => {
      ev.preventDefault();
      const raw = parseNum(form.amount.value);
      const err = $('.form-error', form);
      if (!Number.isFinite(raw) || raw === 0) { err.textContent = 'أدخل المبلغ'; err.hidden = false; form.amount.focus(); return; }
      const currency = form.currency.value;
      const usdRaw = parseNum(form.usd.value);
      const neg = sign.classList.contains('neg');
      const amount = neg ? -Math.abs(raw) : Math.abs(raw);
      const usd = currency === '$' ? amount : Number.isFinite(usdRaw) ? (neg ? -Math.abs(usdRaw) : Math.abs(usdRaw)) : null;
      const data = {
        page: entry ? entry.page : state.page, section: form.section.value, date: form.date.value || null,
        details: form.details.value.trim(), amount, currency, usd, excluded: form.excluded.checked,
        order: entry ? entry.order : Date.now(), by: entry ? entry.by : deviceName(),
      };
      state.lastSection[data.page] = data.section; saveJSON('hesabat.lastSection', state.lastSection);
      const p = entry ? store.update(entry.id, data) : store.add(data);
      p.catch((e) => toast('تعذّر الحفظ: ' + (e.message || e)));
      closeSheet();
      toast(entry ? 'تم حفظ التعديل' : 'تمت الإضافة');
    });
    $('[data-close]', form).addEventListener('click', () => closeSheet());
  });
}

function confirmDelete(entry) {
  openSheet(`
    <div class="sheet-head"><h3>حذف القيد؟</h3></div>
    <p class="confirm-text">${money(entry.amount, entry.currency)} — ${esc(entry.details || 'بدون تفاصيل')} — ${fmtDate(entry.date)}</p>
    <p class="muted">سيُحذف من الهاتفين.</p>
    <div class="sheet-actions">
      <button class="btn danger" data-yes>نعم، احذف</button>
      <button class="btn ghost" data-close>تراجع</button>
    </div>`, (root) => {
    $('[data-yes]', root).addEventListener('click', () => {
      store.remove(entry.id).catch((e) => toast('تعذّر الحذف: ' + (e.message || e)));
      closeSheet(); toast('تم الحذف');
    });
    $('[data-close]', root).addEventListener('click', () => openEntry(entry));
  });
}

/* ---------------- الإعدادات ---------------- */
function openSettings() {
  const count = state.entries.length;
  openSheet(`
    <div class="sheet-head"><h3>الإعدادات</h3></div>
    <label class="field">
      <span>اسم هذا الجهاز <small class="muted">(يظهر بجانب كل قيد تضيفه)</small></span>
      <input id="dev-name" value="${esc(deviceName())}">
    </label>
    <div class="settings-block">
      <div><b>البيانات</b><div class="muted">${count} قيد ${isConfigured ? '— متزامنة بين الهاتفين' : '— وضع المعاينة (على هذا الجهاز فقط)'}</div></div>
      <label class="btn ghost file-btn">استيراد بيانات الإكسل (ملف ‎.json)<input type="file" id="import-file" accept=".json,application/json" hidden></label>
      ${!isConfigured && window.SEED_DATA ? '<button class="btn ghost" id="reseed">استعادة بيانات الإكسل</button>' : ''}
      <button class="btn ghost" id="export">تصدير نسخة احتياطية</button>
      <button class="btn ghost" id="export-csv">تصدير إلى Excel (CSV)</button>
    </div>
    ${isConfigured ? '<button class="btn ghost" id="logout">تسجيل الخروج</button>' : ''}
    <div class="sheet-actions"><button class="btn primary" data-close>تم</button></div>
  `, (root) => {
    $('#dev-name', root).addEventListener('change', (e) => {
      try { localStorage.setItem('hesabat.device', e.target.value.trim()); } catch (_) { /* ignore */ }
    });
    $('[data-close]', root).addEventListener('click', () => {
      try { localStorage.setItem('hesabat.device', $('#dev-name', root).value.trim()); } catch (_) { /* ignore */ }
      closeSheet();
    });
    $('#import-file', root).addEventListener('change', (e) => importFile(e.target.files[0]));
    $('#export', root).addEventListener('click', exportJSON);
    const rs = $('#reseed', root);
    if (rs) rs.addEventListener('click', async () => {
      await store.importAll(window.SEED_DATA.entries, true); closeSheet(); toast('تمت استعادة بيانات الإكسل');
    });
    $('#export-csv', root).addEventListener('click', exportCSV);
    const lo = $('#logout', root);
    if (lo) lo.addEventListener('click', async () => { await store.signOut(); location.reload(); });
  });
}

async function importFile(file) {
  if (!file) return;
  let data;
  try { data = JSON.parse(await file.text()); } catch (_) { toast('الملف غير صالح'); return; }
  const list = Array.isArray(data) ? data : data.entries;
  if (!Array.isArray(list) || !list.length) { toast('الملف لا يحتوي بيانات'); return; }
  const replace = state.entries.length > 0;
  openSheet(`
    <div class="sheet-head"><h3>استيراد ${list.length} قيد</h3></div>
    <p class="muted">${replace ? `يوجد حالياً ${state.entries.length} قيد. سيتم استبدالها بالكامل بمحتوى الملف.` : 'ستُضاف القيود وتظهر على الهاتفين.'}</p>
    <div class="sheet-actions">
      <button class="btn primary" data-yes>استيراد</button>
      <button class="btn ghost" data-close>إلغاء</button>
    </div>`, (root) => {
    $('[data-yes]', root).addEventListener('click', async (ev) => {
      ev.target.disabled = true; ev.target.textContent = 'جارٍ الاستيراد…';
      try { await store.importAll(list.map((e) => ({ ...e, by: e.by || 'الإكسل' })), replace); toast('تم الاستيراد'); }
      catch (e) { toast('فشل الاستيراد: ' + (e.message || e)); }
      closeSheet();
    });
    $('[data-close]', root).addEventListener('click', () => closeSheet());
  });
}

function download(name, text, type) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([text], { type }));
  a.download = name; document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
}
function exportJSON() {
  const entries = state.entries.map(({ id, createdAt, updatedAt, ...e }) => e);
  download(`حسابات-${today()}.json`, JSON.stringify({ version: 1, entries }, null, 1), 'application/json');
}
function exportCSV() {
  const rows = [['الصفحة', 'القسم', 'التاريخ', 'التفاصيل', 'المبلغ', 'العملة', 'ما يعادل بالدولار', 'لا يحسب', 'أضيف من']];
  PAGES.forEach((p) => sectionsOf(p).forEach((s) => sortEntries(entriesOf(p.id, [s.id])).reverse().forEach((e) => {
    rows.push([p.title, s.title, e.date || '', e.details, e.amount, e.currency, e.usd ?? '', e.excluded ? 'نعم' : '', e.by || '']);
  })));
  const csv = '﻿' + rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\r\n');
  download(`حسابات-${today()}.csv`, csv, 'text/csv');
}

/* ---------------- تنبيه صغير ---------------- */
let toastTimer;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg; t.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 2200);
}

/* ---------------- تسجيل الدخول ---------------- */
function showLogin() {
  $('#app').hidden = true;
  const box = $('#login'); box.hidden = false;
  const form = $('#login-form');
  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const err = $('.form-error', form); err.hidden = true;
    const btn = $('button', form); btn.disabled = true; btn.textContent = 'جارٍ الدخول…';
    try {
      await store.signIn(form.email.value, form.password.value);
      box.hidden = true; startApp();
    } catch (e) {
      err.textContent = /network/i.test(e.code || '') ? 'لا يوجد اتصال بالإنترنت' : 'البريد أو كلمة المرور غير صحيحة';
      err.hidden = false; btn.disabled = false; btn.textContent = 'دخول';
    }
  });
}

/* ---------------- التشغيل ---------------- */
function setPage(id, push = true) {
  if (!pageById(id)) id = 'main';
  state.page = id;
  if (push) history.replaceState(history.state, '', '#' + id);
  render();
  window.scrollTo({ top: 0 });
}

function startApp() {
  $('#app').hidden = false;
  if (!isConfigured) $('#demo-banner').hidden = false;
  state.page = pageById(location.hash.slice(1)) ? location.hash.slice(1) : 'main';
  render();
  store.subscribe((list, meta) => {
    state.entries = list.map((e) => ({ ...e, amount: Number(e.amount) || 0 }));
    state.sync = meta.state === 'cache' && navigator.onLine ? 'connecting' : !navigator.onLine && meta.state !== 'local' ? 'cache' : meta.state;
    renderPage(); renderStatus(); if (drawerOpen) renderNav();
  }, (err) => { console.error(err); state.sync = 'error'; renderStatus(); toast('خطأ: ' + (err.code || err.message)); });
  window.addEventListener('online', () => { if (state.sync === 'cache') { state.sync = 'pending'; renderStatus(); } });
  window.addEventListener('offline', () => { if (isConfigured) { state.sync = 'cache'; renderStatus(); } });
}

document.addEventListener('click', (ev) => {
  const t = ev.target;
  const tab = t.closest('[data-page]');
  if (tab) {
    const id = tab.dataset.page;
    if (drawerOpen) { closeDrawer(); setTimeout(() => setPage(id), 60); } else setPage(id);
    return;
  }
  if (t.closest('#menu-btn')) { openDrawer(); return; }
  if (t.closest('[data-drawer-close]')) { closeDrawer(); return; }
  const add = t.closest('[data-add]');
  if (add) { openEntry(null, add.dataset.add); return; }
  const col = t.closest('[data-collapse]');
  if (col) {
    const k = col.dataset.collapse; state.collapsed[k] = !state.collapsed[k];
    saveJSON('hesabat.collapsed', state.collapsed); renderPage(); return;
  }
  const row = t.closest('.entry');
  if (row) { const e = state.entries.find((x) => x.id === row.dataset.id); if (e) openEntry(e); return; }
  if (t.closest('#fab')) { openEntry(null); return; }
  if (t.closest('#settings-btn')) {
    if (drawerOpen) { closeDrawer(); setTimeout(openSettings, 80); } else openSettings();
    return;
  }
  if (t.id === 'sheet-backdrop') closeSheet();
});
document.addEventListener('keydown', (ev) => {
  if (ev.key === 'Enter' && ev.target.matches('.entry, [data-collapse]')) ev.target.click();
  if (ev.key === 'Escape') { if (sheetOpen) closeSheet(); else if (drawerOpen) closeDrawer(); }
});

(async function boot() {
  try {
    const { user } = await store.init();
    $('#splash').remove();
    if (!user) showLogin(); else startApp();
  } catch (e) {
    console.error(e);
    $('#splash').innerHTML = `<p>تعذّر تشغيل التطبيق — تأكد من الاتصال بالإنترنت ثم أعد فتحه.</p><button class="btn primary" onclick="location.reload()">إعادة المحاولة</button>`;
  }
})();

if ('serviceWorker' in navigator && location.protocol === 'https:' && !window.Capacitor) {
  navigator.serviceWorker.register('./sw.js').catch(() => {});
}
