// طبقة البيانات: Firebase (مزامنة فورية بين الهاتفين) أو تخزين محلي في وضع المعاينة
import { firebaseConfig } from '../firebase-config.js';

const FB_VERSION = '10.12.2';
export const isConfigured = !!(firebaseConfig.apiKey && firebaseConfig.projectId);

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const clean = (e) => ({
  page: e.page, section: e.section, date: e.date || null, details: e.details || '',
  amount: Number(e.amount) || 0, currency: e.currency || '$',
  usd: e.usd === null || e.usd === undefined || e.usd === '' ? null : Number(e.usd),
  excluded: !!e.excluded, order: Number(e.order) || Date.now(), by: e.by || '',
});

/* ---------------- وضع المعاينة (localStorage) ---------------- */
function localStore() {
  const KEY = 'hesabat.entries.v1';
  let listeners = [];
  const read = () => {
    try {
      const raw = localStorage.getItem(KEY);
      const saved = raw ? JSON.parse(raw) : null;
      if (Array.isArray(saved) && saved.length) return saved;
    } catch (_) { /* ignore */ }
    const seed = (window.SEED_DATA && window.SEED_DATA.entries) || [];
    return seed.map((e) => ({ id: uid(), ...clean(e) }));
  };
  let data = read();
  const save = () => {
    try { localStorage.setItem(KEY, JSON.stringify(data)); } catch (_) { /* ignore */ }
    listeners.forEach((cb) => cb(data.slice(), { state: 'local' }));
  };
  window.addEventListener('storage', (ev) => {
    if (ev.key === KEY) { data = read(); listeners.forEach((cb) => cb(data.slice(), { state: 'local' })); }
  });
  return {
    mode: 'local',
    async init() { return { user: { email: 'معاينة' } }; },
    subscribe(cb) { listeners.push(cb); cb(data.slice(), { state: 'local' }); return () => { listeners = listeners.filter((l) => l !== cb); }; },
    async add(e) { data.push({ id: uid(), ...clean(e) }); save(); },
    async update(id, e) { data = data.map((x) => (x.id === id ? { ...x, ...clean({ ...x, ...e }) } : x)); save(); },
    async remove(id) { data = data.filter((x) => x.id !== id); save(); },
    async importAll(entries, replace) {
      if (replace) data = [];
      entries.forEach((e) => data.push({ id: uid(), ...clean(e) }));
      save();
    },
    async signOut() {},
  };
}

/* ---------------- Firebase ---------------- */
function firebaseStore() {
  let fb, auth, db, col;
  async function load() {
    // في نسخة الأندرويد/الآيفون تكون مكتبة Firebase مضمّنة في مجلد vendor
    let base = `https://www.gstatic.com/firebasejs/${FB_VERSION}/`;
    try {
      const r = await fetch('./vendor/firebase-app.js', { method: 'HEAD' });
      if (r.ok) base = new URL('./vendor/', location.href).href;
    } catch (_) { /* use CDN */ }
    const [app, a, f] = await Promise.all([
      import(base + 'firebase-app.js'), import(base + 'firebase-auth.js'), import(base + 'firebase-firestore.js'),
    ]);
    fb = { ...app, ...a, ...f };
    const fapp = fb.initializeApp(firebaseConfig);
    auth = fb.initializeAuth(fapp, { persistence: [fb.indexedDBLocalPersistence, fb.browserLocalPersistence] });
    try {
      db = fb.initializeFirestore(fapp, { localCache: fb.persistentLocalCache({ tabManager: fb.persistentMultipleTabManager() }) });
    } catch (_) {
      db = fb.getFirestore(fapp);
    }
    col = fb.collection(db, 'entries');
  }
  return {
    mode: 'firebase',
    async init() {
      await load();
      return new Promise((resolve) => {
        const off = fb.onAuthStateChanged(auth, (user) => { off(); resolve({ user }); });
      });
    },
    async signIn(email, password) {
      await fb.signInWithEmailAndPassword(auth, email.trim(), password);
    },
    async signOut() { await fb.signOut(auth); },
    subscribe(cb, onError) {
      return fb.onSnapshot(col, { includeMetadataChanges: true }, (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
        cb(list, {
          state: snap.metadata.hasPendingWrites ? 'pending' : snap.metadata.fromCache ? 'cache' : 'synced',
        });
      }, onError);
    },
    async add(e) { await fb.addDoc(col, { ...clean(e), createdAt: fb.serverTimestamp() }); },
    async update(id, e) { await fb.updateDoc(fb.doc(db, 'entries', id), { ...clean(e), updatedAt: fb.serverTimestamp() }); },
    async remove(id) { await fb.deleteDoc(fb.doc(db, 'entries', id)); },
    async importAll(entries, replace) {
      const ops = [];
      if (replace) {
        const snap = await fb.getDocs(col);
        snap.docs.forEach((d) => ops.push((b) => b.delete(d.ref)));
      }
      entries.forEach((e) => ops.push((b) => b.set(fb.doc(col), { ...clean(e), createdAt: fb.serverTimestamp() })));
      for (let i = 0; i < ops.length; i += 400) {
        const batch = fb.writeBatch(db);
        ops.slice(i, i + 400).forEach((op) => op(batch));
        await batch.commit();
      }
    },
  };
}

export const store = isConfigured ? firebaseStore() : localStore();
