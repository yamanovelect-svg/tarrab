// يحفظ ملفات التطبيق ليعمل بسرعة وبدون إنترنت (البيانات نفسها تحفظها Firebase)
const CACHE = 'tarrab-v1';
const SHELL = ['./', './index.html', './css/styles.css', './js/app.js', './js/store.js', './js/pages.js',
  './firebase-config.js', './manifest.webmanifest', './fonts/brand.ttf', './icons/icon-192.png', './icons/icon-180.png'];
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
    .then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET') return;
  const cacheable = url.origin === location.origin || url.host === 'fonts.googleapis.com' || url.host === 'fonts.gstatic.com'
    || (url.host === 'www.gstatic.com' && url.pathname.startsWith('/firebasejs/'));
  if (!cacheable) return;
  // الشبكة أولاً (لتصل التحديثات)، ثم النسخة المحفوظة عند انقطاع الإنترنت
  e.respondWith(fetch(e.request).then((res) => {
    if (res.ok || res.type === 'opaque') { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(e.request, copy)); }
    return res;
  }).catch(() => caches.match(e.request, { ignoreSearch: true }).then((r) => r || caches.match('./index.html'))));
});
